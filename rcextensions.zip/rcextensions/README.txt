This is template rcextensions.

To edit rcextensions please edit hooks.py file.
The examples/ directory contain some basic example how to use hooks.


Changes to rcextensions requires restart of RhodeCode instances.
